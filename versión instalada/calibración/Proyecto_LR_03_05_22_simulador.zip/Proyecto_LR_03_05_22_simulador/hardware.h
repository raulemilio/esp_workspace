//Prototipos de funciones de hardware
void hardSetup();
void ensayo(int estadoint,int *ptr_laser_sel);
bool armado(int *ptr_laser_sel);
