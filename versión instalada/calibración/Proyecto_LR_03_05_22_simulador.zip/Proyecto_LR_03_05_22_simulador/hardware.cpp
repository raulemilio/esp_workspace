#include <Arduino.h>
//Variables globales de hardware
             int x_pos = 0;
             int pasos_p_inicializacion=20;//defecto
             //Ensayo Simulados
             int datosSimulados[]={1,55,57,55,51,46,43,36,30,29,23,20,21,23,28,33,41,48,56,62,68,74,80,83,82,81,79,77,72,65,61,51,43,34,28,24,23,25,25,33,39,49,54,64,72,80,82,88,91,89,89,85,80,71,65,55,45,39,34,29,28,31,40,50,63,74,89,99,112,118,128,131,132,132,128,123,113,105,93,81,66,54,44,37,35,37,44,58,74,95,112,130,145,157,165,173,175,175,170,162,149,137,121,104,82,64,53,41,41,54,74,102,132,157,184,209,229,247,258,266,271,268,267,256,243,227,202,175,141,110,88,67,67,107,142,188,239,284,322,360,385,388,423,435,439,432,424,412,405,388,358,314,272,214,167,138,184,297,395,473,533,588,630,672,715,739,756,769,789,803,813,823,836,846,846,870,978,996,1001,996,970,888,851,831,823,811,807,797,786,780,779,750,708,668,634,593,537,475,395,311,233,174,145,167,225,273,317,368,402,417,429,428,428,427,420,402,379,349,318,283,244,199,152,110,72,50,50,67,101,134,167,197,217,232,245,254,256,254,244,233,217,199,176,150,123,96,73,49,32,29,34,48,69,91,110,129,143,153,163,166,168,166,157,151,137,125,106,92,73,55,41,31,22,26,35,42,53,69,80,91,100,108,110,115,114,111,106,98,89,78,68,57,45,36,28,22,18,21,27,33,42,53,61,66,75,76,80,81,81,77,73,68,60,53,44,36,30,25,20,20,18,21,27,31,35,41,48,49,54,57,57,59,57,54,50,47,43,37,31,25,22,19,17,13,14,16,18,22,27,28,35,34,37,37,39,39,38,35,35,31,26,22,19,18,17,17,17,19,21,21,25,27,30,31,33,34,37,36,34,33,30,30,28,25,20,19,17,15,13,12,10,11,12,12,13,15,16,18,20,22,22,23,24,24,22,21,21,18,16,18,17,18,17,15,15,19,19,19,21,20,23,21,21,20,21,21,21,17,17,13,14,12,10,10,8,9,9,9,10,9,11,12,13,12,12,15,16,14,13,16,16,15,12,11,14,13,10,9,8,6,8,8,10,8,6,9,11,10,12,12,10,10,13,10,12,11,11,9,10,12,11,10,10,11,10,11,10,11,12,11,11,13,9,11,10,11,10,9,9,6,5,5,2,7,3,3,3,5,5,6};
             //Ensayo Simulados
//Defino pasos por cada punto adquirido
            #define pasos_p_adquisicion 3
            #define pasos_p_inicializacion_experimentoA_laserVerde 20
            #define pasos_p_inicializacion_experimentoB_laserRojo  1003// los pasos totales son 2007  / la mitad 1003           

//Declarando pines de entrada/salida
    //Pines de control de motores
        //Motor de Pickup (Cabezal de adquisición de intensidad lumínica)
            #define EN1   10
            #define STEP1 11
            #define DIR1  12
        //Motor de selección de blanco (Intercambio de diferentes elementos difractantes 
        //(Regillas, alambres, etc.))
            #define EN2   7
            #define STEP2 8
            #define DIR2  9
    //Pines de Salida digitales
          //Selección de Laser
            #define Laser_Verde A2 //ANTES 5
            #define Laser_Rojo  6
    //Pines Entrada/salida digitales
            #define I_inicio  3    
            #define I_final  2            
            #define D_aux  4    
    //Entradas analógicas
            #define Int_Luz  A0
            #define A_AUX1   A1
            #define A_AUX2   A2
            #define A_AUX3   A3
//-------------------------------------------------------------------------------------------------------------------


void hardSetup()
{
  //Incialización de entrada/salida;
    //Pines de control de motores
        //Motor de Pickup (Cabezal de adquisición de intensidad lumínica)
            pinMode(EN1,OUTPUT); digitalWrite(EN1,1); //Inicalizo el motor 1 DESHABILITADO
            pinMode(STEP1,OUTPUT);
            pinMode(DIR1,OUTPUT);
        //Motor de selección de blanco (Intercambio de diferentes elementos difractantes (Regillas, alambres, etc.))
            pinMode(EN2,OUTPUT); digitalWrite(EN1,1); //Inicalizo el motor 2 DESHABILITADO
            pinMode(STEP2,OUTPUT);
            pinMode(DIR2,OUTPUT);
        //Pines de Salida digitales
            pinMode(I_inicio,INPUT);    
            pinMode(I_final,INPUT);            
        //Selección de Laser
            pinMode(Laser_Verde,OUTPUT); digitalWrite(Laser_Verde,0);
            pinMode(Laser_Rojo,OUTPUT); digitalWrite(Laser_Rojo,0); 
        //Pines Entrada/salida digitales
            pinMode(D_aux,OUTPUT); digitalWrite(D_aux,0);   
}
//___________________________________________________________________________________________________________________

void ensayo(int estado,int *ptr_laser_sel)
{
   char sel = 'N';
   //if (x_pos < 5) {

    if (( estado == 8 ) and (x_pos == 0))  sel = 'R';      //estado de START
    else if (( estado == 32 ) && (x_pos >= 0) && (!(digitalRead(I_final)))) sel = 'O';   //estado de CONTINUACIÓN
    //else sel = 'N';}
    else  sel = 'S';  //estado de STOP
    
    switch(sel){
      case 'N':
      break;
      case 'R':{
          //Enciendo Laser_Rojo/verde CUANDO INICIA EL ENSAYO
             if (*ptr_laser_sel == 1)digitalWrite(Laser_Rojo,1);// experimento B 
             else if (*ptr_laser_sel == 0)digitalWrite(Laser_Verde,1);// experimento A 
          //Envío de trama
          Serial.print('P');Serial.print(',');Serial.print("D");
          Serial.print(',');Serial.print(x_pos++);Serial.print(',');
          Serial.print(datosSimulados[0]);Serial.print(',');
          Serial.println('$');          
      break;}
      case 'O':{
         //Movimiento de motor y adquisición
           digitalWrite(EN1,1); delay(5);
           digitalWrite(DIR1,0); delay(5);
           digitalWrite(EN1,0); delay(5); //Cambio de giro
           for (int j = 1; j < pasos_p_adquisicion; j++)
           {
             digitalWrite(STEP1,HIGH);
             delay(5);
             digitalWrite(STEP1,LOW);
             delay(5);    
           }
            digitalWrite(EN1,1); delay(5); //deshabilito
          //Envío de trama
          Serial.print('P');Serial.print(',');Serial.print("D");
          Serial.print(',');Serial.print(x_pos++);Serial.print(',');
          Serial.print(datosSimulados[(x_pos-1)]);Serial.print(',');
          Serial.println('$');
      break;}
      case 'S':{
          //Movimiento de motor y adquisición
           digitalWrite(EN1,1); delay(5); 
           digitalWrite(DIR1,1); delay(5); 
           digitalWrite(EN1,0); delay(5); //Cambio de giro
           for (int j = 1; j < pasos_p_inicializacion; j++)
           {
             digitalWrite(STEP1,HIGH);
             delay(5);
             digitalWrite(STEP1,LOW);
             delay(5);    
           }
           digitalWrite(EN1,1);
          //Envío de trama
          Serial.print('P');Serial.print(',');Serial.print("S");
          Serial.print(',');Serial.print(x_pos++);Serial.print(',');
          Serial.print(datosSimulados[(x_pos-1)]);Serial.print(',');
          Serial.println('$');
          //apago Laser_Rojo/verde CUANDO INICIA EL ENSAYO
             if (*ptr_laser_sel == 1) digitalWrite(Laser_Rojo,0);
             else if (*ptr_laser_sel == 0) digitalWrite(Laser_Verde,0);
          break;}
    }

}

//___________________________________________________________________________________________________________________
bool armado(int *ptr_laser_sel)
{
  //Posición inicial del sensor  CUANDO INICIA EL ENSAYO
   if (*ptr_laser_sel == 1)
   {
    pasos_p_inicializacion=pasos_p_inicializacion_experimentoA_laserVerde;// experimento A 
   }
   else
    {
      if (*ptr_laser_sel == 0)
      {
        pasos_p_inicializacion=pasos_p_inicializacion_experimentoB_laserRojo;// experimento B 
      }
    }

   long TimeOut = millis ();
   bool falla = false;
   digitalWrite(EN1,1); delay(5);
   digitalWrite(DIR1,1); delay(5);
   digitalWrite(EN1,0); delay(5); //Cambio de giro
   while (!(digitalRead(I_inicio)))
   {
         digitalWrite(STEP1,HIGH);
         delay(5);
         digitalWrite(STEP1,LOW);
         delay(5);    
         if (millis() > TimeOut + 30000) {falla = true; break;} // verifica que el fin de carrera fue presionado o que paso un timeout
   }
   if (falla){
    digitalWrite(EN1,1);
    return(false);
   }
   else
   {
     x_pos = 0;
     digitalWrite(DIR1,0);
     for (int j = 1; j < pasos_p_inicializacion; j++)
     {
       digitalWrite(STEP1,HIGH);
       delay(5);
       digitalWrite(STEP1,LOW);
       delay(5);    
     }
     digitalWrite(EN1,1);
     digitalWrite(Laser_Rojo,0);// apagado de laser
     digitalWrite(Laser_Verde,0);// apagado de laser
     return(true);
   }
}
