
//Prototipos de funciones
 int trama_verif (String trama, int estado);
void Limpiar_campos ();
 int Extraer_campos (String trama, int estado,int *ptr_laser_sel);
void lcdMuestra (int estado);
void disp_setup();
